import os
import json
import time
import html
import psutil
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler
)
from config import OWNER_ID
from storage.entity_cache import load as load_cache
from services.userbot import client

BASE_DIR = "storage"
ADMINS_FILE = os.path.join(BASE_DIR, "admins.json")
BANNED_FILE = os.path.join(BASE_DIR, "banned_users.json")
ADMIN_LOG = os.path.join(BASE_DIR, "admin_log.txt")

os.makedirs(BASE_DIR, exist_ok=True)

BOT_START_TIME = time.time()


# ===============================
# UTIL JSON
# ===============================
def _load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path, "r") as f:
        return json.load(f)


def _save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# ===============================
# ADMIN & ACCESS
# ===============================
def get_admins():
    data = _load_json(ADMINS_FILE, {"admins": []})
    return data.get("admins", [])


def save_admins(admins):
    _save_json(ADMINS_FILE, {"admins": admins})


def is_owner(uid):
    return uid == OWNER_ID


def is_admin(uid):
    return is_owner(uid) or uid in get_admins()


def is_banned(uid):
    data = _load_json(BANNED_FILE, {"banned": []})
    return uid in data.get("banned", [])


def log_admin(action):
    with open(ADMIN_LOG, "a") as f:
        f.write(f"[{time.ctime()}] {action}\n")


# ===============================
# MAIN PANEL
# ===============================
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_admin(uid):
        return

    keyboard = [
        [InlineKeyboardButton("👥 User", callback_data="admin_users")],
        [InlineKeyboardButton("📦 Cache", callback_data="admin_cache")],
        [InlineKeyboardButton("⚙️ Status", callback_data="admin_status")],
    ]

    if is_owner(uid):
        keyboard.append(
            [InlineKeyboardButton("👮 Admin", callback_data="admin_admins")]
        )

    await update.message.reply_text(
        "🛠️ <b>ADMIN PANEL</b>\n━━━━━━━━━━━━━━━━━━━━",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )


# ===============================
# CALLBACK ROUTER
# ===============================
async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = query.from_user.id

    if not is_admin(uid):
        return

    data = query.data

    if data == "admin_users":
        await query.edit_message_text(
            "👥 <b>USER MANAGEMENT</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Commands:\n"
            "/ban <id>\n"
            "/unban <id>\n"
            "/banned",
            parse_mode="HTML"
        )

    elif data == "admin_cache":
        cache = load_cache()
        await query.edit_message_text(
            "📦 <b>CACHE INFO</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Total entity : {len(cache)}\n\n"
            "Commands:\n"
            "/cache_stats\n"
            "/cache_del <id>\n"
            "/cache_clear",
            parse_mode="HTML"
        )

    elif data == "admin_status":
        mem = psutil.Process().memory_info().rss // (1024 * 1024)
        uptime = int(time.time() - BOT_START_TIME)
        await query.edit_message_text(
            "⚙️ <b>BOT STATUS</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Userbot : {'ONLINE' if client.is_connected() else 'OFFLINE'}\n"
            f"Uptime  : {uptime}s\n"
            f"Memory  : {mem} MB",
            parse_mode="HTML"
        )

    elif data == "admin_admins" and is_owner(uid):
        admins = get_admins()
        await query.edit_message_text(
            "👮 <b>ADMIN LIST</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            + ("\n".join(str(a) for a in admins) if admins else "-"),
            parse_mode="HTML"
        )


# ===============================
# USER BAN COMMANDS
# ===============================
async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_admin(uid):
        return

    if not context.args:
        await update.message.reply_text("Gunakan: /ban <user_id>")
        return

    target = int(context.args[0])
    data = _load_json(BANNED_FILE, {"banned": []})

    if target not in data["banned"]:
        data["banned"].append(target)
        _save_json(BANNED_FILE, data)
        log_admin(f"BAN {target} by {uid}")

    await update.message.reply_text(f"🚫 User {target} dibanned")


async def unban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_admin(uid):
        return

    if not context.args:
        await update.message.reply_text("Gunakan: /unban <user_id>")
        return

    target = int(context.args[0])
    data = _load_json(BANNED_FILE, {"banned": []})

    if target in data["banned"]:
        data["banned"].remove(target)
        _save_json(BANNED_FILE, data)
        log_admin(f"UNBAN {target} by {uid}")

    await update.message.reply_text(f"✅ User {target} diunban")


# ===============================
# ADMIN MANAGEMENT (OWNER)
# ===============================
async def add_admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_owner(uid):
        return

    target = int(context.args[0])
    admins = get_admins()

    if target not in admins:
        admins.append(target)
        save_admins(admins)
        log_admin(f"ADD ADMIN {target}")

    await update.message.reply_text(f"👮 Admin {target} ditambahkan")


async def del_admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_owner(uid):
        return

    target = int(context.args[0])
    admins = get_admins()

    if target in admins:
        admins.remove(target)
        save_admins(admins)
        log_admin(f"DEL ADMIN {target}")

    await update.message.reply_text(f"❌ Admin {target} dihapus")


# ===============================
# SETUP
# ===============================
def setup(app):
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern="^admin_"))

    app.add_handler(CommandHandler("ban", ban_cmd))
    app.add_handler(CommandHandler("unban", unban_cmd))

    app.add_handler(CommandHandler("addadmin", add_admin_cmd))
    app.add_handler(CommandHandler("deladmin", del_admin_cmd))

