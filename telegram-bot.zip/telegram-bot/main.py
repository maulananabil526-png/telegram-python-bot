import os
import pkgutil
import importlib

from telegram.ext import ApplicationBuilder, CommandHandler
from telegram.request import HTTPXRequest
from telegram import BotCommand
from services.userbot import start_userbot

from config import BOT_TOKEN


# =======================
# POST INIT
# =======================
async def post_init(application):
    # Init shared bot_data
    application.bot_data.setdefault("users", {})
    application.bot_data.setdefault("banned", [])
    application.bot_data.setdefault("history", {})

    # Start userbot sekali
    await start_userbot()
    print("✅ Userbot (Telethon) aktif & terkoneksi")
    # Set command menu
    await application.bot.set_my_commands([
        BotCommand("start", "memulai bot"),
        BotCommand("pairing", "tambah sender"),
        BotCommand("cekbio", "cek bio"),
        BotCommand("generate", "acak email"),
        BotCommand("cekid", "id grup/chanel"),
        BotCommand("info", "reply teks/tag user"),
        BotCommand("cinfo","info grup/chanel"),
        BotCommand("admin","admin panel")
    ])


# =======================
# AUTO LOAD PLUGINS
# =======================
def load_handlers(application):
    handlers_path = os.path.join(os.path.dirname(__file__), "handlers")

    print("🔍 Memuat handlers...")

    for _, name, _ in pkgutil.iter_modules([handlers_path]):
        try:
            module = importlib.import_module(f"handlers.{name}")

            if hasattr(module, "setup"):
                module.setup(application)
                print(f"🧩 Handlers dimuat: {name}")
            else:
                print(f"⚠️ Handlers dilewati (tanpa setup): {name}")

        except Exception as e:
            print(f"❌ Gagal memuat handler {name}: {e}")

    print("🔥 Semua handler selesai dimuat")


# =======================
# MAIN
# =======================
def main():
    request = HTTPXRequest(
        connection_pool_size=8,
        connect_timeout=30,
        read_timeout=60,
        write_timeout=60
    )

    application = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .request(request)
        .post_init(post_init)
        .build()
    )

    # Load all plugins automatically
    load_handlers(application)

    print("🤖 Telegram bot running...")
    application.run_polling(drop_pending_updates=True)


# =======================
# ENTRY POINT
# =======================
if __name__ == "__main__":
    main()

