
BOT_TOKEN = "×××××××××"
BRIDGE_FILE = "../shared/bridge.json"
OWNER_ID = xxxxxxx

# ===============================
# TELETHON USERBOT
# ===============================
API_ID = ××××××××××
API_HASH = "××××××××"
# ===============================
# BOT SETTINGS (OPTIONAL)
# ===============================

# Mode debug (print log tambahan)
DEBUG = True

# Cooldown default (detik)
DEFAULT_COOLDOWN = 5

# Maksimal generate default
MAX_GENERATE = 2000

# Folder session (Telegram userbot & WA kalau ada)
SESSION_DIR = "sessions"
